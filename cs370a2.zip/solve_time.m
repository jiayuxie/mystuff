%
% solve_time.m
%
% Solve NxN systems using 2 methods, for various sizes of N.

Ns = 10:1:200;
M = 20;

% Store the timing results here
t_method1 = zeros(size(Ns));
t_method2 = zeros(size(Ns));

idx = 1;

% Loop over N-values (for both methods)
% Generate random A and B

for N = Ns
    % Generate random matrices
    A = rand(N);
    B = rand(N,M);
    X = zeros(size(B)); % allocate space for X
    L = zeros(size(A));
    U = zeros(size(A));
    Y = zeros(size(B));
    
    % === Method 1 ===
    tic;
    
    % *** YOUR CODE HERE ***
    % Solve the M vector systems individually using \
    X = A\B;
    t_method1(idx) = toc;  % [1] Use tic and toc
    
    
    % === Method 2 ===
    tic;
    
    % *** YOUR CODE HERE ***
    % Compute LU factorization, then use it to solve each of the M vector
    % systems.
    [L,U]=lu(A);
    Y = L\B;
    X = U\Y;
    t_method2(idx) = toc;
    
    
    idx = idx + 1;
    
end


%% Plot
x=10:1:200;
plot(x,t_method1);
text(200,t_method1(190),'\leftarrow m1');
hold on;
plot(x,t_method2);
text(200,t_method2(190),'\leftarrow m2');
xlabel('N');
ylabel('time');
% Plot both lines on one axis.
% Be sure to label your plot.

