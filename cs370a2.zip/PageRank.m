% function [p, iters] = PageRank(G, alpha)
%
% Computes the Google Page-rank for the network in the adjacency matrix G.
%
% Input
%   G is an adjacency matrix, G(i,j) = 1 iff node j projects to node i
%   alpha is a scalar between 0 and 1
%
% Output
%   p is a probability vector containing the Page-rank of each node
%   iters is the number of iterations used to achieve a tolerance of 1e-8
%
function [p, iters] = PageRank(G, alpha)
    R = size(G,1);  % number of nodes
    p = ones(R,1);
    p = p/R;
    iters = 0;
    D = sparse(R,R);
    col_sum = full(sum(G));
    for i=1:R
        D(i,i)=1/(col_sum(i));
        if(col_sum(i)==0)
            D(i,i)=0;
        end
    end
    P = G*D; %%bulid possibility matrix
    e = ones(R,1);
    d = sparse(1,R);
    for i=1:R
        if col_sum(i)==0
            d(i)=1;
        end
    end
    while(1)
    temp_p = p;
    p = alpha*P*p+(alpha/R)*e*(d*p)+((1-alpha)/R)*e;
    iters = iters +1;
    if(max(abs(p-temp_p))<=1e-8)
           break;       
    end
    end
   
    
