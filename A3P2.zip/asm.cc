#include "kind.h"
#include "lexer.h"
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
// Use only the neeeded aspects of each namespace
using std::string;
using std::vector;
using std::endl;
using std::cerr;
using std::cin;
using std::cout;
using std::ostringstream;
using std::getline;
using ASM::Token;
using ASM::Lexer;
using ASM::Kind;

//helperfuction

void output(vector<Token*>);
int DecToBin(int);
void outputbin(int);
int check(vector<Token*>);
int main(int argc, char* argv[]){
  // Nested vector representing lines of Tokens
  // Needs to be used here to cleanup in the case
  // of an exception
  vector< vector<Token*> > tokLines;
  try{
    // Create a MIPS recognizer to tokenize
    // the input lines
    Lexer lexer;
    // Tokenize each line of the input
    string line;
    while(getline(cin,line)){
      tokLines.push_back(lexer.scan(line));
    }

    // Iterate over the lines of tokens and print them
    // to standard error
    vector<vector<Token*> >::iterator it;
    for(it = tokLines.begin(); it != tokLines.end(); ++it){
      int c =check(*it);
      if (c ==0){
       cerr<<"ERROR"<<endl;
       return 0;
      }
    }
    for(it = tokLines.begin(); it != tokLines.end(); ++it){
      vector<Token*>::iterator it2;
      for(it2 = it->begin(); it2 != it->end(); ++it2){
        cerr << "  Token: "  << *(*it2) << endl;
      }
    }

  } catch(const string& msg){
    // If an exception occurs print the message and end the program
    cerr << msg << endl;
  } 
    vector<vector<Token*>>::iterator it;
    for(it = tokLines.begin();it!=tokLines.end(); ++it){
  
        output(*it);
    }
  // Delete the Tokens that have been made
  for(it = tokLines.begin(); it != tokLines.end(); ++it){
    vector<Token*>::iterator it2;
    for(it2 = it->begin(); it2 != it->end(); ++it2){
      delete *it2;
    }
  }
  
}
int check(vector<Token*> line){
  if (line.size()==0)
    return 1; 
  if(line[0]->getKind() == Kind::DOTWORD){
     if (line.size()==1){
       return 0;
      }
     if (line[1]->getKind()!=Kind::HEXINT && line[1]->getKind()!=Kind::INT){
       return 0;
     }
     else return 1;
   } 
}

void output(vector<Token*> line){
  int bin;
  if (line.size() == 0)
   return ;
  if (line[0]->getKind()==Kind::DOTWORD){
      int dec = line[1]->toInt();
      bin = DecToBin(dec);
      outputbin(bin); 
 }
}



int DecToBin(int dec){
  int result = dec;
  int q;
  int bin = 0;
  int cur = 0;
  if (dec == -2147483648)
    return bin = 1 <<31;
  else if (dec < 0)
   result = -result;
  while (result>0){
   q = result % 2;
   if(q ==1){
     q=q<<cur;
     bin = q | bin;
    }
   cur++;      
   result /= 2;
  }
 if (dec <0){
   bin =~bin;
   bin ++;
 }
 return bin;
}  


void outputbin(int word){
  putchar((word>>24) & 0xff);
  putchar((word>>16) & 0xff);
  putchar((word>>8) & 0xff);
  putchar(word &0xff); 
}
