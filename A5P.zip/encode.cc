#include "tree.h"
#include <fstream>
using namespace std;
int main(){
  tree thetree;
  int inputnum =0;
  int curcap =128;
  int codelen=0;
  char a;
  while((a=getchar())!=EOF){
    cout<<thetree.charvec[a].code;
    thetree.charvec[a].freq++;
    inputnum++;
    if (inputnum==curcap){
       if (curcap==128){
          for(int i=0;i<thetree.charvec.size();i++){
             thetree.charvec[i].freq--;
          }
       }
       curcap = curcap*2;
       thetree.bulid_tree();
   }
 }
  if (curcap==128){
      for(int i=0;i<thetree.charvec.size();i++){
           thetree.charvec[i].freq--;
           }
 }
  fstream freq;
  freq.open("huff.freq",std::fstream::out);
  fstream code;
  code.open("huff.code",std::fstream::out);
  fstream wpl;
  wpl.open("huff.wpl",std::fstream::out);
  for (int i=0;i<thetree.charvec.size();i++){
    freq<<thetree.charvec[i].freq<<endl;
    code<<thetree.charvec[i].code<<endl;
  }
  for(int i=0;i<thetree.charvec.size();i++){
	codelen += thetree.charvec[i].freq * thetree.charvec[i].code.length();
 }
  wpl <<codelen;
  freq.close();
  code.close();
  wpl.close();
}
