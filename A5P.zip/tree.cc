#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <utility>
#include <stack>
#include "tree.h"
using namespace std;

void tree:: bulid_tree(){
      if (root != NULL){
        delete root;
      }
      root = NULL;
      vector<onechar> freqvec;     
      for (int i=0;i<charvec.size();i++){
         char c = charvec[i].c;
         int freq  = charvec[i].freq;
        // cout<<c<<" "<<freq<<endl;
         onechar copy(c,freq);
        // cout<<copy.c<<" "<<copy.freq<<endl;
         freqvec.push_back(copy);
        // cout<<freqvec[i].c<<" "<<freqvec[i].freq<<endl;
      }      
      quicksort(freqvec,0,freqvec.size()-1);
      stack<node*> nodestk;
      for (int i=127;i>=0;i--){
        nodestk.push(new node(freqvec[i].c,"char",NULL,freqvec[i].freq));
      }
      deque<node*> nodeque;
      while(1){
        if (nodeque.size()+nodestk.size()==1){
          if (nodeque.size()==1){
             root = nodeque.front();
            }
          else root = nodestk.top(); 
          break;
        }
        if (nodestk.size()==0){
           int size = nodeque.size();
           for (int i =0;i<size;i++){
             node* temp = nodeque.back();
             nodeque.pop_back();
             nodestk.push(temp);
           }
        }
        if (nodestk.size()==1){
          node* node1 =nodestk.top();
          nodestk.pop();
          node1->addcode("0");
          node* node2 = nodeque.front();
          nodeque.pop_front();
          node2->addcode("1");
          int weight = node1->weight + node2->weight;
          node* newnode = new node('n',"null",NULL,weight);
          newnode ->left =node1;
          newnode ->right = node2;
          node1->parent = newnode;
          node2->parent = newnode;
          nodeque.push_back(newnode);
          continue;
        }
        node* node1 = nodestk.top();
        nodestk.pop();
        node* node2 = nodestk.top();
        nodestk.pop();
        int weight1 = node1->weight;
        int weight2 = node2->weight;
        if ((nodeque.size()==0)||(weight2<nodeque.front()->weight)){
          int weight = weight1 + weight2;
          node* newnode = new node('n',"null",NULL,weight);
          newnode->left = node1;
          node1->addcode("0");
          newnode->right = node2; 
          node2->addcode("1");    
          node1->parent = newnode;
          node2->parent = newnode;
          nodeque.push_back(newnode);
         }
        else{
          nodestk.push(node2);
          node2 = nodeque.front();
          weight2 = node2->weight;
          nodeque.pop_front();
          if (nodeque.size()!=0){
            node* node3 = nodeque.front();
            int weight3 = node3->weight;
            if(weight1>weight3){
              cout<<"if"<<endl;
              nodestk.push(node1);
              nodeque.pop_front();
              int weight = weight2+weight3;
              node* newnode= new node('n',"null",NULL,weight);
              newnode->left = node2;
              node2->addcode("0");
              newnode->right = node3;
              node3->addcode("1");
              node2->parent = newnode;
              node3->parent = newnode;
              nodeque.push_back(newnode);
              continue;
            }
          }
          int weight = weight1 + weight2;
          node* newnode = new node('n',"null",NULL,weight);
          newnode->left = node1;
          node1->addcode("0");
          newnode->right = node2;
          node2->addcode("1");
          node1->parent = newnode;
          node2->parent = newnode;
          nodeque.push_back(newnode);
         }
   }
  updatecode(root);
}

void tree:: updatecode(node* iter){
  if ((iter->left==NULL)&&(iter->right==NULL)){
     int num =iter->c;
     charvec[num].code = iter->code;
     return;
   }
  updatecode(iter->left);
  updatecode(iter->right);
} 
int partition(vector<onechar>& vec,int left,int right){
  int pivot = vec[right].freq;
  int i = left-1;
  int j;
  for (j=left;j<right;j++){
    if (vec[j].freq<pivot){
        i++;
        swap(vec[i],vec[j]);
       }
    else if ((vec[j].freq==pivot) &&( vec[j].c<vec[right].c)){
       i++;
       swap(vec[i],vec[j]);
      }
  }
  swap(vec[i+1],vec[right]);
  return i+1 ;
}

void quicksort(vector<onechar>& vec,int left,int right){
    if (left >= right) return;
    int pivo = partition(vec,left,right);
    quicksort(vec,left,pivo -1);
    quicksort(vec,pivo+1,right);
}

          
