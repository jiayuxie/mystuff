#include "tree.h"
using namespace std;

int main(){
  tree thetree;
  int inputnum=0;
  int curcap = 128;
  char a;
  node* iter = thetree.root;
  while((a=getchar())!=EOF){
     if (a=='0'){
        iter = iter->left;
      }
     if (a=='1'){
        iter =iter->right;
     }
     if((iter->left==NULL)&&(iter->right==NULL)){
         cout<<iter->c;
         thetree.charvec[iter->c].freq++;
         iter = thetree.root;
         inputnum++;
       if(inputnum==curcap){
 	  if(curcap==128){
	    for(int i =0;i<thetree.charvec.size();i++){
	      thetree.charvec[i].freq--;
            }
          }
        curcap = curcap *2;
	thetree.bulid_tree();
  	iter = thetree.root;
     }
   }
 }
}
       
