#include <vector>
#include <string>
#include <iostream>

class onechar{
  public:
  char c=0;
  int freq=0;
  std::string code="";
  onechar(){}
  onechar(char thechar,int thefreq){
    c =thechar;
    freq = thefreq;
  }
};
class node{
  public:
    node* left=NULL;
    node* right=NULL;
    node* parent=NULL;
    std::string code="";
    int weight=0;
    char c=0;
    std::string type="";
    node(char thechar,std::string thetype,node* p,int w){
      c = thechar;
      type = thetype;
      parent = p;
      weight = w;
    }
    void addcode(std::string s){
       code = s + code;
       if(left!=NULL){
       left->addcode(s);
      }
       if(right!=NULL){
       right->addcode(s);
      }
     }
    ~node(){
       delete left;
       delete right;
     }
};

class tree {
  public:
    node* root=NULL;
    std::vector<onechar> charvec;
    tree(){
      charvec.resize(128);
      for(int i =0;i<128;i++){
        char c = i;
        onechar thechar(c,1);
        charvec[i]=thechar;
     }
      root = NULL;
      bulid_tree();
     }
   void bulid_tree();
   void updatecode(node*);
};
//helper======================
int partition(std::vector<onechar>&,int,int);
void quicksort(std::vector<onechar>&,int,int);













