#include<iostream>
#include<vector>

using namespace std;
class item {
	public:
	  item(){}
	  int v=0;
	  vector<int> indexlist;
};	

void veccop(vector<int>& vd,vector<int>& vs){
	int size = vs.size();
	vd.clear();
	for(int i=0;i<size;i++){
		vd.push_back(vs[i]);
	}
}
int main(){
 	int item_num;
	int cap;
	cin>>item_num>>cap;
	vector<vector<item>> result;
	cap++;
	result.resize(cap);
	for(int i=0;i<cap;i++){
		result[i].resize(item_num);
       }
	//init complete
	for(int i=0;i<item_num;i++){
		int weight;
		int value;
		cin>>weight>>value;
		if (i==0){
		  for(int j=1;j<cap;j++){
		    if (weight>j){continue;}
		    else{
			result[j][i].v=value;
			result[j][i].indexlist.push_back(i+1);
		   }
	       	 }
	       }
		else{
		  for(int j=1;j<cap;j++){
	  	    if(weight>j){
		      result[j][i].v=result[j][i-1].v;
		      veccop(result[j][i].indexlist,result[j][i-1].indexlist);
		    }
		    else if ((value+result[j-weight][i-1].v)>result[j][i-1].v){
		      result[j][i].v=result[j-weight][i-1].v+value;
		      veccop(result[j][i].indexlist,result[j-weight][i-1].indexlist);
		      result[j][i].indexlist.push_back(i+1);
		   }
		   else{
		      result[j][i].v=result[j][i-1].v;
		      veccop(result[j][i].indexlist,result[j][i-1].indexlist);
		  }
	         }
	       }
	}
//	for(int i=0;i<item_num;i++){
//		for(int j=0;j<cap;j++){
//		  cout<<result[j][i].v<<","<<result[j][i].indexlist.size()<<" ";
//		}
//		cout<<"\n";
//	}
	vector<int> list;
	veccop(list,result[cap-1][item_num-1].indexlist);
	cout<<result[cap-1][item_num-1].v<<" "<<list.size()<<endl;
	for(int i=0;i<list.size();i++){
		cout<<list[i]<<" ";
	}
	return 0;
}
	      
	
		  
		
	
