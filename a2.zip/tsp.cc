#include<iostream>
#include<vector>
#include<queue>
#include<cmath>
#include<time.h>
#include<stdlib.h>
#include<utility>
using namespace std;


class TSP{
	public:
	vector<vector<int>> distance;
	int city_num=0;
	int T=10000;//initial temperature;
	double cool =0.999999; //setup cooling operator
	int cur_cost,new_cost;
	TSP(int num){
		city_num = num;
		distance.resize(city_num);
                for(int i = 0;i<city_num;i++){
                  distance[i].resize(city_num);
                }
	}
	int rand_climb(){
		int rand_num = rand()%100 +100;
		int p = exp(-(new_cost-cur_cost)/T);
		p *= 100;
		if(rand_num <= p) return 1;
		else {return 0;}
	}		
		
		
		
};
class city{
	public:
	int x,y;
	char name;
	city(char s){name =s;}
};

int main(){
	srand((unsigned)time(NULL));
	int city_num=0;
	cin>>city_num;
	vector<city> city_list;
	for(int i=0;i<city_num;i++){
		char city_name;
		cin>>city_name;
		city curcity(city_name);
		int x,y;
		cin>>x>>y;
		curcity.x=x;	
		curcity.y=y;
		city_list.push_back(curcity);
	}
	TSP theTSP(city_num);
	//calculate distance
	for (int i=0;i<city_num;i++){
		int from_x = city_list[i].x;
		int from_y = city_list[i].y;
	  for(int j=0;j<city_num;j++){
		int cost;
		if(i==j) cost=0;
		else {
		  int to_x = city_list[j].x;
		  int to_y = city_list[j].y;
		  cost = sqrt(pow(from_x-to_x,2)+pow(from_y-to_y,2));
		}
		theTSP.distance[i][j]=cost;
	 }
	}
	//test distance
//	for(int i =0;i<city_num;i++){
//		for(int j=0;j<city_num;j++){
//			cout<<distance_m[i][j]<<" ";
//		}
//		cout<<endl;
//	}

	//start annealing
	vector<int> curpath;
	for(int i = 0;i<city_num;i++){
	 	curpath.push_back(i); //initial path A-B-C-...-A;
	}
	curpath.push_back(0);
	for(int i=0;i<curpath.size();i++){
		theTSP.cur_cost += theTSP.distance[curpath[i]][curpath[i+1]];
	}//initail path cost
	int min = theTSP.cur_cost;
	while(theTSP.T>0.001){
		if (theTSP.cur_cost<min) min = theTSP.cur_cost;
		int rand_swap_a = (rand() % (city_num-1))+1;
		int rand_swap_b = (rand() % (city_num-1))+1;
		while(rand_swap_a==rand_swap_b){
			rand_swap_b = (rand()%(city_num-1))+1;
		}
		vector<int> temp_path = curpath;
		swap(curpath[rand_swap_a],curpath[rand_swap_b]);
		for(int i=0;i<curpath.size()-1;i++){
			theTSP.new_cost+=theTSP.distance[curpath[i]][curpath[i+1]];
		}
		if(theTSP.new_cost < theTSP.cur_cost || theTSP.rand_climb()){
			theTSP.cur_cost = theTSP.new_cost;
			theTSP.new_cost = 0;
			theTSP.T = theTSP.T*theTSP.cool;
			cout<<theTSP.cur_cost<<endl;
		}
		else{
			theTSP.new_cost =0;
			curpath = temp_path;
			theTSP.T = theTSP.T*theTSP.cool;
		}
		
      }
	for(int i=0;i<curpath.size();i++){
		//display result
	//	char a;
		//a = curpath[i]+65;
		cout<<curpath[i]<<" ";
	}
	cout<<"cost = "<<theTSP.cur_cost<<endl;
	cout<<"min = "<<min<<endl;
		 	
}
