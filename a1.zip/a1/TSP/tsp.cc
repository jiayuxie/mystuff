#include<iostream>
#include<vector>
#include<queue>
#include<cmath>
using namespace std;

class city{
	public:
	int x,y;
	char name;
	city(char a){
		name = a;
	}
};
class node{
	public:
	int finish;//number of cities that already visited
	vector<int> visited_path;//a list of visited city_name
	int fvalue=0;
	int curcity=0;
	vector<int> isvisited;//a list of bool represent which city is visited or not
	node(int city_num){
		isvisited.resize(city_num);
	}		
};

class TSP{
	public:
	vector<vector<int>> distance;
	int city_num=0;
	int min=0;
	int nodenum=0;
	queue<node> open;
	vector<node> close;
	TSP(int num){
		city_num = num;
		distance.resize(city_num);
                for(int i = 0;i<city_num;i++){
                  distance[i].resize(city_num);
                }
	}
	int gvalue(node curnode){
		int g=0;
		for (int i=0;i<curnode.finish-1;i++){
			int from = curnode.visited_path[i];
			int to = curnode.visited_path[i+1];
			int dis = distance[from][to];
			g += dis;
		}
		return g;
	}
	int hvalue(int finish){
		int h = min*(city_num-finish+1);
			return h;
	}
		
};

void fsort(vector<node>& extend){
	for(int i=0;i<extend.size();i++){
		for(int j=0;j<extend.size()-i-1;j++){
			if(extend[j].fvalue>extend[j+1].fvalue){
				swap(extend[j],extend[j+1]);
			}
		}
	}
}
	
int main(){
	int city_num=0;
	cin>>city_num;
	vector<city> city_list;
	for(int i=0;i<city_num;i++){
		char city_name;
		cin>>city_name;
		city curcity(city_name);
		int x,y;
		cin>>x>>y;
		curcity.x=x;	
		curcity.y=y;
		city_list.push_back(curcity);
	}
	TSP theTSP(city_num);
	//calculate distance
	for (int i=0;i<city_num;i++){
		int from_x = city_list[i].x;
		int from_y = city_list[i].y;
	  for(int j=0;j<city_num;j++){
		int cost;
		if(i==j) cost=0;
		else {
		  int to_x = city_list[j].x;
		  int to_y = city_list[j].y;
		  cost = sqrt(pow(from_x-to_x,2)+pow(from_y-to_y,2));
		}
		theTSP.distance[i][j]=cost;
	 }
	}
	//test distance
//	for(int i =0;i<city_num;i++){
//		for(int j=0;j<city_num;j++){
//			cout<<distance_m[i][j]<<" ";
//		}
//		cout<<endl;
//	}
	//find minimum distance
	int mindis = 99999;
	for(int i=0;i<city_num;i++){
	   for(int j=0;j<city_num;j++){
		int dis = theTSP.distance[i][j];
		if (dis==0) continue;
		else if (dis<mindis) mindis = dis;
         }
       }
	theTSP.min = mindis;
	node start(city_num);
	start.visited_path.push_back(0);//always start in city A,and use 0~25 represent a~z;
	start.isvisited[0]=1;
	start.curcity=0;
	start.fvalue = theTSP.gvalue(start)+theTSP.hvalue(1);
	start.finish++;
	theTSP.open.push(start);
	//start A* search
	while(!theTSP.open.empty()){
		node top = theTSP.open.front();
		theTSP.open.pop();
		theTSP.close.push_back(top);
	//if we visited all city
	  if(top.finish==city_num){
		top.isvisited[0]=0;
	  }
	//if we reach the final state
	  if(top.finish==city_num+1){
		for(int i =0;i<top.visited_path.size();i++){
			char c = top.visited_path[i]+65;
			cout<<c<<" ";
		}
		
//		cout<<theTSP.nodenum<<" ";
		break;
	  }
	vector<node> extend;
	for (int i =0;i<city_num;i++){
	  if (!top.isvisited[i]){
	    theTSP.nodenum++;
	    node curnode(city_num);
	    curnode.finish = top.finish+1;
	    curnode.curcity = i;
	    curnode.visited_path=top.visited_path;
	    curnode.visited_path.push_back(i);
	    curnode.isvisited = top.isvisited;
	    curnode.isvisited[i]=1;
	    curnode.fvalue = theTSP.gvalue(curnode)+theTSP.hvalue(curnode.finish);
	    extend.push_back(curnode);
	  }
	}
	fsort(extend);	
	for(int i=0;i<extend.size();i++){
		theTSP.open.push(extend[i]);
	}	  
	
      }
		 	
}
