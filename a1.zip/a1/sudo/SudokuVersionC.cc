#include<iostream>
#include<vector>
using namespace std;
class delitem {
	public:
	int value;
	int count;
	delitem(int v){
		value = v;
		count =1;
	}
};
class cell {
	public:
	vector<int> candidate;
	int value;
	int r;
	int c;
	vector<delitem> overdelete;
	cell(){
		for (int i=1;i<10;i++){
			candidate.push_back(i);
		}
		value = 0;
	}
};
	
class sudoku {
	public:
	 	vector<vector<cell>> sudo;
	 	int assignment=0;//for counting varainces assignments
		sudoku(){
			sudo.resize(9);
			for(int i=0;i<9;i++){
				sudo[i].resize(9);
			}
			for(int i=0;i<9;i++){
				for(int j=0;j<9;j++){
					sudo[i][j].r=i;
					sudo[i][j].c=j;
				}
			}
		}
		void PrintSudo(){
			for(int r=0;r<9;r++){
				for(int c=0;c<9;c++){
			  		cout<<sudo[r][c].value<<" ";
				//	for(int i=0;i<sudo[r][c].candidate.size();i++){
				//		cout<<sudo[r][c].candidate[i]<<",";
				//	}
				//	cout<<") ";
				}
			  cout<<endl;
			}
			cout<<"assignments="<<assignment<<endl;
		}
		bool rmCandidate(int r,int c,int v){
			int cannum = sudo[r][c].candidate.size();
			bool find=false;
			for(int i=0;i<cannum;i++){
				if(sudo[r][c].candidate[i]==v){
					find =true;
					sudo[r][c].candidate.erase(sudo[r][c].candidate.begin()+i);
					if(sudo[r][c].candidate.size()==0 && sudo[r][c].value == 0){
						return false;
					}
				}
			}
			if (find==false){
				for (int i=0;i<sudo[r][c].overdelete.size();i++){
					if ( sudo[r][c].overdelete[i].value == v){
						sudo[r][c].overdelete[i].count++;
						return true;
					}
				}
				delitem item(v);
				sudo[r][c].overdelete.push_back(item);
				return true;
			}
			return true;
		}	
             void recCandidate(int r,int c,int v){
                        for(int i =0;i<sudo[r][c].overdelete.size();i++){
                                if(sudo[r][c].overdelete[i].value==v){
                                        sudo[r][c].overdelete[i].count--;
                                        if(sudo[r][c].overdelete[i].count==0){
                                                sudo[r][c].overdelete.erase(sudo[r][c].overdelete.begin()+i);
                                        }
                                return;
                                }
                        }
                        for(int j = 0;j<sudo[r][c].candidate.size();j++){
                                if(sudo[r][c].candidate[j]==v){
                                        return;
                                }
			}
                            sudo[r][c].candidate.push_back(v);
         
                }
	//if mode=0,delete all relative candidate,if mode =1 ,recover all the candidate
		bool dealCandidate(int r,int c,int mode){
			int value = sudo[r][c].value;
			int succ = true;
			for (int i=0;i<9;i++){
				if ( i != r){ 
					if(mode==0){
					//cout<<"rm"<<i<<","<<c<<endl;
					bool flag = rmCandidate(i,c,value);
					if (flag == false){succ=false;}
					//cout<<flag<<endl;
					}
					else{
					recCandidate(i,c,value);
					}
				}
			}	
			for (int j=0;j<9;j++){
				if(j!=c){
				     if(mode==0){
	   				 //cout<<"rm"<<r<<","<<j<<endl;
					bool flag = rmCandidate(r,j,value);
					if(flag == false){succ = false;}
				//	cout<<flag<<endl;
				     }
				     else{recCandidate(r,j,value);}
				}
			}
			int temprow = r/3;
			int tempcol = c/3;
			for(int i=0;i<3;i++){
				for(int j=0;j<3;j++){
					if(temprow*3+i !=r && tempcol*3+j !=c){
						if(mode==0){
				//		    cout<<"rm"<<temprow*3+i<<","<<tempcol*3+j<<endl;
						  bool flag = rmCandidate(temprow*3+i,tempcol*3+j,value);
						  if(flag == false){succ=false;}
				//		  cout<<flag<<endl;
						}
						else{recCandidate(temprow*3+i,tempcol*3+j,value);}
					}
				}
		
			}
			return succ;	
		}	
	void findnext(int& r,int& c){
		int size=0;
		int min =9;
		vector<cell> canlist;
		int remain=0;
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				if(sudo[i][j].value!=0) continue;
				else{
					size = sudo[i][j].candidate.size();
					remain++;
					if(size<min) min=size;
				}
			}
		}
		if(remain==0){
			PrintSudo();
			exit(0);
		}
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				if(min==sudo[i][j].candidate.size() && sudo[i][j].value==0){
					canlist.push_back(sudo[i][j]);
				}
			}
		}
		if(canlist.size()==1){
			r = canlist[0].r;
			c = canlist[0].c;
		}
		else{
			vector<int> constlist;
			int max=0;
			for(int k =0;k<canlist.size();k++){
				int cur_r = canlist[k].r;
				int cur_c = canlist[k].c;
				int cur_const =0;
				for(int i=0;i<9;i++){
					if(sudo[i][cur_c].value!=0) cur_const++;
				}
				for(int j=0;j<9;j++){
					if(sudo[cur_r][j].value!=0) cur_const++;
				}
				int temprow = cur_r/3;
				int tempcol = cur_c/3;
				for(int i =0;i<3;i++){
					for(int j=0;j<3;j++){
						if(temprow*3+i !=cur_r && tempcol*3+j != cur_c){
							if(sudo[temprow*3+i][tempcol*3+j].value!=0) cur_const++;
						}
					}
				}
				constlist.push_back(cur_const);
				if (cur_const>max) max=cur_const;
			}
			for(int i =0;i<constlist.size();i++){
				if(constlist[i]==max){
					r = canlist[i].r;
					c = canlist[i].c;
				}
			}
		}
	}
				
								
	void forwardCheck(int r,int c){
		
		if(sudo[r][c].value==0){
			
			vector<int> candidatecopy = sudo[r][c].candidate;
			while(sudo[r][c].candidate.size()){
				sudo[r][c].value=sudo[r][c].candidate[0];
				assignment++;
		//		if(assignment==10000){
		//			cout<<10000<<" ";
		//			exit(0);
		//		}
				rmCandidate(r,c,sudo[r][c].value);
				bool flag = dealCandidate(r,c,0);
				if(!flag){
					dealCandidate(r,c,1);
					continue;
				}
				else{
					int nextr = 0;
					int nextc = 0;
					findnext(nextr,nextc);
					forwardCheck(nextr,nextc);
					dealCandidate(r,c,1);
				}
			}
			sudo[r][c].value =0;
			sudo[r][c].candidate = candidatecopy;
		}
		else{
			int nextr =0;
			int nextc =0;
			findnext(nextr,nextc);
			forwardCheck(nextr,nextc);}
		}
			
};

int main(){
	sudoku Sudoku;
	for(int i=0;i<9;i++){
		for(int j=0;j<9;j++){
			int num =0;
			cin>>num;
			Sudoku.sudo[i][j].value=num;
			if(num!=0){Sudoku.dealCandidate(i,j,0);}
		}
	}
	int firstc,firstr;
	Sudoku.findnext(firstr,firstc);
	Sudoku.forwardCheck(firstr,firstc);
}
					

		
