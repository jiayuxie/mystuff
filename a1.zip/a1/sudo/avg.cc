#include<iostream>
using namespace std;

int main(){
	int count=0;
	int cursum=0;
	int timeout=0;
	for(int i=0;i<710;i++){
		int v;
		cin>>v;
		cursum+=v;
		count++;
		if(v==10000) timeout++;
		if(count==10){
			cout<<"avg="<<cursum/10<<" timeout:"<<timeout<<endl;
			cursum=0;
			timeout=0;
			count=0;
		}
	}
}
