#include<iostream>
#include<vector>
using namespace std;
class delitem {
	public:
	int value;
	int count;
	delitem(int v){
		value = v;
		count =1;
	}
};
class cell {
	public:
	vector<int> candidate;
	int value;
	vector<delitem> overdelete;
	cell(){
		for (int i=1;i<10;i++){
			candidate.push_back(i);
		}
		value = 0;
	}
};
	
class sudoku {
	public:
	 	vector<vector<cell>> sudo;
	 	int assignment=0;//for counting varainces assignments
		sudoku(){
			sudo.resize(9);
			for(int i=0;i<9;i++){
				sudo[i].resize(9);
			}
		}
		void PrintSudo(){
			for(int r=0;r<9;r++){
				for(int c=0;c<9;c++){
			  		cout<<sudo[r][c].value<<" ";
				//	for(int i=0;i<sudo[r][c].candidate.size();i++){
				//		cout<<sudo[r][c].candidate[i]<<",";
				//	}
				//	cout<<") ";
				}
			  cout<<endl;
			}
			cout<<"assignment="<<assignment<<endl;
		}
		bool rmCandidate(int r,int c,int v){
			int cannum = sudo[r][c].candidate.size();
			bool find=false;
			for(int i=0;i<cannum;i++){
				if(sudo[r][c].candidate[i]==v){
					find =true;
					sudo[r][c].candidate.erase(sudo[r][c].candidate.begin()+i);
					if(sudo[r][c].candidate.size()==0 && sudo[r][c].value == 0){
						return false;
					}
				}
			}
			if (find==false){
				for (int i=0;i<sudo[r][c].overdelete.size();i++){
					if ( sudo[r][c].overdelete[i].value == v){
						sudo[r][c].overdelete[i].count++;
						return true;
					}
				}
				delitem item(v);
				sudo[r][c].overdelete.push_back(item);
				return true;
			}
			return true;
		}	
             void recCandidate(int r,int c,int v){
                        for(int i =0;i<sudo[r][c].overdelete.size();i++){
                                if(sudo[r][c].overdelete[i].value==v){
                                        sudo[r][c].overdelete[i].count--;
                                        if(sudo[r][c].overdelete[i].count==0){
                                                sudo[r][c].overdelete.erase(sudo[r][c].overdelete.begin()+i);
                                        }
                                return;
                                }
                        }
                        for(int j = 0;j<sudo[r][c].candidate.size();j++){
                                if(sudo[r][c].candidate[j]==v){
                                        return;
                                }
			}
                            sudo[r][c].candidate.push_back(v);
         
                }
	//if mode=0,delete all relative candidate,if mode =1 ,recover all the candidate
		bool dealCandidate(int r,int c,int mode){
			int value = sudo[r][c].value;
			int succ = true;
			for (int i=0;i<9;i++){
				if ( i != r){ 
					if(mode==0){
					//cout<<"rm"<<i<<","<<c<<endl;
					bool flag = rmCandidate(i,c,value);
					if (flag == false){succ=false;}
					//cout<<flag<<endl;
					}
					else{
					recCandidate(i,c,value);
					}
				}
			}	
			for (int j=0;j<9;j++){
				if(j!=c){
				     if(mode==0){
	   				 //cout<<"rm"<<r<<","<<j<<endl;
					bool flag = rmCandidate(r,j,value);
					if(flag == false){succ = false;}
				//	cout<<flag<<endl;
				     }
				     else{recCandidate(r,j,value);}
				}
			}
			int temprow = r/3;
			int tempcol = c/3;
			for(int i=0;i<3;i++){
				for(int j=0;j<3;j++){
					if(temprow*3+i !=r && tempcol*3+j !=c){
						if(mode==0){
				//		    cout<<"rm"<<temprow*3+i<<","<<tempcol*3+j<<endl;
						  bool flag = rmCandidate(temprow*3+i,tempcol*3+j,value);
						  if(flag == false){succ=false;}
				//		  cout<<flag<<endl;
						}
						else{recCandidate(temprow*3+i,tempcol*3+j,value);}
					}
				}
		
			}
			return succ;	
		}		
	void forwardCheck(int r,int c){
		
		if(r==8 && c==9){
			PrintSudo();
			exit(0);
		}
		if(c==9){
			r++;
			c=0;
		}
		if(sudo[r][c].value==0){
			
			vector<int> candidatecopy = sudo[r][c].candidate;
			while(sudo[r][c].candidate.size()){
				sudo[r][c].value=sudo[r][c].candidate[0];
				assignment++;
		//		if(assignment==10000){
		//			cout<<10000<<" ";
		//			exit(0);
		//		}
				rmCandidate(r,c,sudo[r][c].value);
				bool flag = dealCandidate(r,c,0);
				if(!flag){
					dealCandidate(r,c,1);
					continue;
				}
				else{
					forwardCheck(r,c+1);
					dealCandidate(r,c,1);
				}
			}
			sudo[r][c].value =0;
			sudo[r][c].candidate = candidatecopy;
		}
		else{forwardCheck(r,c+1);}
		}
			
};

int main(){
	sudoku Sudoku;
	for(int i=0;i<9;i++){
		for(int j=0;j<9;j++){
			int num =0;
			cin>>num;
			Sudoku.sudo[i][j].value=num;
			if(num!=0){Sudoku.dealCandidate(i,j,0);}
		}
	}
	Sudoku.forwardCheck(0,0);
}
					

		
