#include<iostream>
#include<vector>
using namespace std;

class sudoku {
	public:
	 	vector<vector<int>> sudo;
	 	int assignment=0;//for counting varainces assignments
		sudoku(){
			sudo.resize(9);
			for(int i=0;i<9;i++){
				sudo[i].resize(9);
			}
		}
		bool check(int r,int c,int num){
			for(int i=0;i<9;i++){
				if(sudo[r][i]==num) return false;
			}
			for(int j=0;j<9;j++){
				if(sudo[j][c]==num) return false;
			}
			int boxr =r/3;
			int boxc =c/3;
			for(int i=0;i<3;i++){
				for(int j=0;j<3;j++){
					if(sudo[boxr*3+i][boxc*3+j]==num) return false;}
			}
			return true;
		}
		void PrintSudo(){
			for(int r=0;r<9;r++){
				for(int c=0;c<9;c++){
			  		cout<<sudo[r][c]<<" ";
				}
			  cout<<endl;
			}
			cout<<"assignment="<<assignment<<endl;
		}
		void BackTrace(int r,int c){
			//final state;
			if(r==8&&c==9){
				PrintSudo();
				exit(0);	
			}
			//change colnum
			if(c==9){
				r++;
				c=0;
			}
			if(sudo[r][c]==0){
				for(int n=1;n<10;n++){
				  if(check(r,c,n)){
				    sudo[r][c]=n;
				    assignment++;
		//for collecting data	    if(assignment==10000){
		//				cout<<10000<<" ";
		//				exit(0);
		//	}
			            BackTrace(r,c+1);
				  //if programe reach here, we meet a dead end,go back 1 step and try other possible answer
				    sudo[r][c]=0;
				  }
				}
	      		}
			else{BackTrace(r,c+1);}
	}
};

int main(){
	sudoku Sudoku;
	for(int i=0;i<9;i++){
		for(int j=0;j<9;j++){
			int num =0;
			cin>>num;
			Sudoku.sudo[i][j]=num;
		}
	}
	Sudoku.BackTrace(0,0);
}
					

		
