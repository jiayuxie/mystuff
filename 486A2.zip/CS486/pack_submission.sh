#!/usr/bin/env bash

zip a2-submission.zip basicplayer.py connectfour.py implementation.py main.py tests.py tree_searcher.py util.py LICENSE
